import React, { useState, useEffect, Component, PropsWithChildren } from "react";
import { StyleSheet, View, ActivityIndicator, Text, ScrollView, Pressable } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SplashScreen from "expo-splash-screen";
import * as Font from "expo-font";
import { Feather, Ionicons, MaterialIcons, FontAwesome } from "@expo/vector-icons";
import {
  Nunito_400Regular,
  Nunito_500Medium,
  Nunito_600SemiBold,
  Nunito_700Bold,
  Nunito_800ExtraBold,
} from "@expo-google-fonts/nunito";

import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/query-client";

SplashScreen.preventAutoHideAsync();

import RootStackNavigator from "@/navigation/RootStackNavigator";
import OnboardingScreen from "@/screens/OnboardingScreen";
import { ThemeProvider } from "@/contexts/ThemeContext";

const ONBOARDING_KEY = "@haibo_onboarding_complete";

// ─── Safe Error Boundary ─────────────────────────────────────────────────────
// This error boundary does NOT depend on ThemeProvider or any other context.
// It uses only plain React Native components so it can never crash itself.
type SafeErrorState = { error: Error | null; errorInfo: string };

class SafeErrorBoundary extends Component<PropsWithChildren<{}>, SafeErrorState> {
  state: SafeErrorState = { error: null, errorInfo: "" };

  static getDerivedStateFromError(error: Error): Partial<SafeErrorState> {
    return { error };
  }

  componentDidCatch(error: Error, info: { componentStack: string }) {
    this.setState({ errorInfo: info.componentStack });
  }

  render() {
    if (this.state.error) {
      return (
        <View style={{ flex: 1, backgroundColor: "#ffffff", padding: 24, paddingTop: 60 }}>
          <Text style={{ color: "#E72369", fontSize: 22, fontWeight: "bold", marginBottom: 8 }}>
            Something went wrong
          </Text>
          <Text style={{ color: "#333333", fontSize: 14, marginBottom: 16 }}>
            {this.state.error.message}
          </Text>
          <Pressable
            onPress={() => this.setState({ error: null, errorInfo: "" })}
            style={{
              backgroundColor: "#E72369",
              paddingVertical: 12,
              paddingHorizontal: 24,
              borderRadius: 8,
              alignSelf: "flex-start",
              marginBottom: 16,
            }}
          >
            <Text style={{ color: "#ffffff", fontSize: 16, fontWeight: "600" }}>Try Again</Text>
          </Pressable>
          <ScrollView style={{ flex: 1 }}>
            <Text style={{ color: "#666666", fontSize: 11, fontFamily: "monospace" }}>
              {this.state.error.stack}
            </Text>
            <Text style={{ color: "#E72369", fontSize: 13, fontWeight: "bold", marginTop: 16 }}>
              Component Stack:
            </Text>
            <Text style={{ color: "#666666", fontSize: 11, fontFamily: "monospace" }}>
              {this.state.errorInfo}
            </Text>
          </ScrollView>
        </View>
      );
    }
    return this.props.children;
  }
}

function AppContent() {
  const [isLoading, setIsLoading] = useState(true);
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    async function loadResourcesAndData() {
      try {
        await Font.loadAsync({
          ...Feather.font,
          ...Ionicons.font,
          ...MaterialIcons.font,
          ...FontAwesome.font,
          Nunito_400Regular,
          Nunito_500Medium,
          Nunito_600SemiBold,
          Nunito_700Bold,
          Nunito_800ExtraBold,
        });
        setFontsLoaded(true);
      } catch (e) {
        console.warn("Error loading fonts:", e);
        setFontsLoaded(true);
      }
    }

    loadResourcesAndData();
    checkOnboardingStatus();
  }, []);

  const checkOnboardingStatus = async () => {
    try {
      const hasCompletedOnboarding = await AsyncStorage.getItem(ONBOARDING_KEY);
      setShowOnboarding(hasCompletedOnboarding !== "true");
    } catch (error) {
      setShowOnboarding(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOnboardingComplete = async () => {
    try {
      await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    } catch (error) {
      console.error("Failed to save onboarding status:", error);
    }
    setShowOnboarding(false);
  };

  useEffect(() => {
    async function hideSplash() {
      if (fontsLoaded && !isLoading) {
        try {
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn("Error hiding splash screen:", e);
        }
      }
    }
    hideSplash();
  }, [fontsLoaded, isLoading]);

  if (!fontsLoaded || isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#E72369" />
      </View>
    );
  }

  if (showOnboarding) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  return (
    <NavigationContainer>
      <RootStackNavigator />
      <StatusBar style="auto" />
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <SafeErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <ThemeProvider>
            <QueryClientProvider client={queryClient}>
              <AppContent />
            </QueryClientProvider>
          </ThemeProvider>
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </SafeErrorBoundary>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

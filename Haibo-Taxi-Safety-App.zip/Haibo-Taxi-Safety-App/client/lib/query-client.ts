import { QueryClient, QueryFunction } from "@tanstack/react-query";

/**
 * Gets the base URL for the Express API server (e.g., "http://localhost:3000")
 * Returns null if EXPO_PUBLIC_DOMAIN is not configured (offline/demo mode)
 * @returns {string | null} The API base URL or null
 */
export function getApiUrl(): string | null {
  let host = process.env.EXPO_PUBLIC_DOMAIN;

  if (!host) {
    console.warn("EXPO_PUBLIC_DOMAIN is not set — API calls will be disabled");
    return null;
  }

  let url = new URL(`https://${host}`);

  return url.href;
}

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

/**
 * Make an API request. Accepts either:
 *   apiRequest(route, options)   — where options has { method, body?, ... }
 *   apiRequest(method, route, data)  — legacy positional form
 * Returns parsed JSON.
 */
export async function apiRequest(
  routeOrMethod: string,
  optionsOrRoute?: string | RequestInit,
  data?: unknown,
): Promise<any> {
  const baseUrl = getApiUrl();

  if (!baseUrl) {
    throw new Error("API is not configured. Please set EXPO_PUBLIC_DOMAIN.");
  }

  let url: URL;
  let fetchInit: RequestInit;

  if (typeof optionsOrRoute === "object") {
    // Called as apiRequest(route, { method, body, ... })
    url = new URL(routeOrMethod, baseUrl);
    fetchInit = {
      ...optionsOrRoute,
      headers: {
        "Content-Type": "application/json",
        ...(optionsOrRoute.headers as Record<string, string> || {}),
      },
      credentials: "include",
    };
  } else if (typeof optionsOrRoute === "string") {
    // Called as apiRequest(method, route, data)
    url = new URL(optionsOrRoute, baseUrl);
    fetchInit = {
      method: routeOrMethod,
      headers: data ? { "Content-Type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    };
  } else {
    // Called as apiRequest(route) — simple GET
    url = new URL(routeOrMethod, baseUrl);
    fetchInit = {
      method: "GET",
      credentials: "include",
    };
  }

  const res = await fetch(url, fetchInit);
  await throwIfResNotOk(res);

  const contentType = res.headers.get("content-type");
  if (contentType && contentType.includes("application/json")) {
    return await res.json();
  }
  return await res.text();
}

type UnauthorizedBehavior = "returnNull" | "throw";
export function getQueryFn<T>(options: {
  on401: UnauthorizedBehavior;
}): QueryFunction<T> {
  const { on401: unauthorizedBehavior } = options;
  return async ({ queryKey }) => {
    const baseUrl = getApiUrl();

    if (!baseUrl) {
      // Return undefined when API is not configured — app runs in offline/demo mode
      // Using undefined (not null) so destructuring defaults like `data: items = []` work correctly
      return undefined as unknown as T;
    }

    const url = new URL(queryKey.join("/") as string, baseUrl);

    const res = await fetch(url, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "returnNull" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import compression from "compression";
import { pool } from "./db";

// Import routes
import authRoutes from "./routes/auth";
import taxiRoutes from "./routes/taxis";
import driverRoutes from "./routes/drivers";
import locationRoutes from "./routes/locations";
import communityRoutes from "./routes/community";
import eventRoutes from "./routes/events";
import walletRoutes from "./routes/wallet";
import deliveryRoutes from "./routes/deliveries";
import rideRoutes from "./routes/rides";
import miscRoutes from "./routes/misc";
import adminRoutes from "./routes/admin";

const app = express();
const PORT = parseInt(process.env.PORT || "8080", 10);

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(",") || ["*"],
  credentials: true,
}));
app.use(compression());
app.use(morgan("combined"));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get("/", (req, res) => {
  res.json({
    name: "Haibo Taxi Safety API",
    version: "1.0.0",
    status: "running",
    timestamp: new Date().toISOString(),
  });
});

app.get("/api/health", async (req, res) => {
  try {
    const client = await pool.connect();
    await client.query("SELECT 1");
    client.release();
    res.json({ status: "healthy", database: "connected", timestamp: new Date().toISOString() });
  } catch (error: any) {
    res.status(503).json({ status: "unhealthy", database: "disconnected", error: error.message });
  }
});

// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/taxis", taxiRoutes);
app.use("/api/drivers", driverRoutes);
app.use("/api/locations", locationRoutes);
app.use("/api/community", communityRoutes);
app.use("/api/events", eventRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/deliveries", deliveryRoutes);
app.use("/api/rides", rideRoutes);
app.use("/api", miscRoutes);
app.use("/api/admin", adminRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Endpoint not found", path: req.path });
});

// Global error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error("Unhandled error:", err);
  res.status(500).json({
    error: "Internal server error",
    message: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// Graceful shutdown
process.on("SIGTERM", async () => {
  console.log("SIGTERM received. Shutting down gracefully...");
  await pool.end();
  process.exit(0);
});

process.on("SIGINT", async () => {
  console.log("SIGINT received. Shutting down gracefully...");
  await pool.end();
  process.exit(0);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Haibo API server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || "development"}`);
});

export default app;
